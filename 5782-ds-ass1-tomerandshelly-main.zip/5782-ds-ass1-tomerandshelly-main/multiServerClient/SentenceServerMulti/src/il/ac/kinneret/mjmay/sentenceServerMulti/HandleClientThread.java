
package il.ac.kinneret.mjmay.sentenceServerMulti;
import org.apache.commons.codec.digest.DigestUtils;


import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import java.io.*;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

public class HandleClientThread extends Thread {
    // Create a HashMap object called capitalCities that will store String keys(NAME OF FILE)  and String values:
    public static ConcurrentHashMap FileVersionHash= new ConcurrentHashMap();  //<filename , digest+datatime>
    public static ConcurrentHashMap<String , String> FileLockHash= new ConcurrentHashMap<String , String>(); //< filename , ip >
    private Socket clientSock;
    private Socket socket1;
    private static boolean LockState ;
    private  static boolean fileExist;
    private      Scanner scanner1;
    /**
     * Initializes the server.
     * @param sock The client socket to handle.
     */
    public HandleClientThread(Socket sock)
    {
        super("HandleClientThread-" + sock.getRemoteSocketAddress().toString());
        this.clientSock = sock;
    }




    //this function return the digest of file, input : path of the file , output : the digest
    private static String Digest(String PathOfFile) throws IOException {
        File fileThatDownload = new File(PathOfFile);
        byte [] filesBytes = Files.readAllBytes(fileThatDownload.toPath());
        String sha256Hex = DigestUtils.sha256Hex(filesBytes);
        return sha256Hex;
    }
    //this function return the date and time
    public static String DateTime(){
        TimeZone tz = TimeZone.getTimeZone("Asia/Jerusalem");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"); // Quoted "Z" to indicate UTC, no timezone offset
        df.setTimeZone(tz);
        String nowAsISO = df.format(new Date()); //thas the data time
        return nowAsISO;
    }

    //this function save the file into a path upload file in the server , it userd in the offer case, if the server decided to download the file .
    private static void saveFile( String FileName, Socket clientSock , String digestDataTime , String uploadFile) throws IOException{
        //path to save the file should be here- need to be in gui (the saving ) .
        FileOutputStream fos = new FileOutputStream(SentenceServerMulti.PathOfTheProject + SentenceServerMulti.fileUpload + FileName);
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        //Upload the file - saving this file to a path temporary folder on the server//////////////////////
        byte[]filebytes = Base64.getDecoder().decode(uploadFile);
        fos.write(filebytes);

        SentenceServerMulti.logger.info("\nThe file download succesfully! ");
        SentenceServerMulti.logger.info("\nThe file download succesfully! ");
        if(FileVersionHash.contains(FileName)){
            FileVersionHash.replace(FileName, digestDataTime);
        }
        else {
            FileVersionHash.put(FileName, digestDataTime);
            SentenceServerMulti.logger.info("The file " + FileName + " version " +digestDataTime);
        }

        System.out.println(FileVersionHash);
        SentenceServerMulti.logger.info("The file : " +FileName + ", version : "+ digestDataTime +"upload to this server");
    }





    /**
     * Runs the server
     * the run get command from the client or the other server that chosen to be first
     * the command are :
     * OFFER  - when one server ask other server to upload file
     * Download - when the client want to download a file or offer say download
     * Upload - when client want upload file (it upload to all servers )
     * lock file - client lock file if he want to upload another one with the same name
     * unlock
     * getversion - every file has a version
     * List - get the list of file that we have in the other server that connect now .
     */
    public void run()
    {

        try{
            // attach a buffered reader and print writer
            Scanner AnswareFrom = new Scanner(clientSock.getInputStream());
            String command = AnswareFrom.nextLine();
            SentenceServerMulti.logger.info("Get "+ command +" from " + clientSock.getInetAddress());
            DataOutputStream AnswareTo = new DataOutputStream(clientSock.getOutputStream());
            PrintWriter out =new PrintWriter(clientSock.getOutputStream());

            //check what the commanf that the client send :

            switch (command) {

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
                case "OFFER" :{

                    boolean LockFileByClient = false;
                    String digestDataTime = AnswareFrom.nextLine();
                    String FileName = AnswareFrom.nextLine();
                    String IpOfClient = AnswareFrom.nextLine();


                    System.out.println(FileLockHash);
                    System.out.println(FileVersionHash);


                    boolean fileExist = FileVersionHash.containsKey(FileName); // True - if the file has a version already
                    boolean fileLockQuestion =  FileLockHash.containsKey(FileName); //True - if the file locked already
                    if(fileExist && fileLockQuestion) {
                        LockFileByClient = FileLockHash.get(FileName).equals(IpOfClient);
                    }
                    // String version = scanner.nextLine();
                    if(!fileExist  || (fileExist && LockFileByClient)){
                        SentenceServerMulti.logger.info("\nThe file doesnt exist in this server ");
                        //download the file to the server
                        SentenceServerMulti.logger.info("\nSend DOWNLOAD to the client! ");
                        AnswareTo.writeBytes("DOWNLOAD\n");

                        try{
                            //values o send to the other server
                            //  AnswareTo.writeBytes(FileName+"\n");
                            //values that came from the otther server (in upload case)
                            String commandfromserverone =  AnswareFrom.nextLine();
                            if (commandfromserverone.equals("OK")) {
                                SentenceServerMulti.logger.info("OK from server One");
                                String uploadFile = AnswareFrom.nextLine(); // get the byte of the file from other server .
                                //this function should save the send file into a upload path in the server  and save it in hash map version
                                saveFile(  FileName , clientSock ,digestDataTime , uploadFile);

                            } else if (commandfromserverone.equals("ERROR")){
                                SentenceServerMulti.logger.info("\nERROR from server one , dont download");
                            }
                        }catch (SocketException e) {
                            e.printStackTrace();
                        }
                    }
                    //the file exist and locked by another client .
                    else{
                        AnswareTo.writeBytes("ERROR");
                    }
                    break;
                }
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//


                //Download case , this saving the file that send by client or another server
                case "DOWNLOAD": {

                    //Upload the file - saving this file to a path temporary folder on the server//////////////////////
                    PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);
                    String FileName = AnswareFrom.nextLine();
                    String pathToSaveTeFiles = SentenceServerMulti.PathOfTheProject+SentenceServerMulti.fileUpload+ FileName;
                    File file = new File(pathToSaveTeFiles);

                    String uploadFile;
                    byte[] filebyte= Files.readAllBytes(Paths.get(file.toString()));
                    uploadFile = Base64.getEncoder().encodeToString(filebyte);
                    outToClient.println(uploadFile);
                    outToClient.println("OK");
                    SentenceServerMulti.logger.info("Download successfully ");

                    break;
                }

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

                case "UPLOAD": {
                    try {

                        PrintWriter printWriter = new PrintWriter(clientSock.getOutputStream(), true);
                        //get information from client
                        String FileName = AnswareFrom.nextLine();
                        String FileSizeString = AnswareFrom.nextLine();
                        String WhoCallMe = AnswareFrom.nextLine();  // return the name :  client or server
                        String IpOfClient = AnswareFrom.nextLine();
                        String uploadFile = AnswareFrom.nextLine();

                        boolean WhoLockTheFileQuestion = false;


                        //----------------------------------------------if the client call me (so I am the first server! )-------------------------------
                        if (WhoCallMe.equals("client")) {
                            SentenceServerMulti.logger.info("client call me !");
                            //check if the file exist
                            boolean fileExist = FileVersionHash.containsKey(FileName);

                            //check the locker of this file and save it .
                            if (FileLockHash.containsKey(FileName)) {
                                WhoLockTheFileQuestion = FileLockHash.get(FileName).equals(IpOfClient); // if the client who upload the file is the same to who lock it so this value true .
                            }


                            //if the file exist and locked , and who locked it was not this client (who trying to upload the file)
                            if (fileExist && WhoLockTheFileQuestion == false) {
                                SentenceServerMulti.logger.info("Server send Error to the client , cant upload the file ");
                                printWriter.println("ERROR");
                                break;
                            }


                            //if the file exist , and locked by the same client who want to upload it  OR if the file doesnt exist
                            //here the upload upload the file to this server(the first one )  to a temporary folder and ofer this file to another server connect now
                            else if ((fileExist && WhoLockTheFileQuestion == true) || (!fileExist)) {

                                //path to save the file should be here- need to be in gui (the saving ) .
                                FileOutputStream fos = new FileOutputStream(SentenceServerMulti.PathOfTheProject + SentenceServerMulti.fileUpload + FileName);

                                //Upload the file - saving this file to a path temporary folder on the server//////////////////////
                                byte[]filebytes = Base64.getDecoder().decode(uploadFile);
                                fos.write(filebytes);

                                //make digest to the file that upload now
                                String digestDataTime = Digest(SentenceServerMulti.PathOfTheProject + SentenceServerMulti.fileUpload + FileName) + "," + DateTime();

                                //save the file to the hash map
                                if(FileVersionHash.contains(FileName)){
                                    FileVersionHash.replace(FileName, digestDataTime);
                                }
                                else {
                                    FileVersionHash.put(FileName, digestDataTime);
                                }

                                System.out.println(FileVersionHash);
                                SentenceServerMulti.logger.info("Hash map files :"+ FileVersionHash);
                                SentenceServerMulti.logger.info("UPLOAD : ok ");
                                printWriter.println("OK");
                            } else {
                                printWriter.println("ERROR");////////////////////
                                SentenceServerMulti.logger.info("Send ERROR to the client");
                            }
                        }//end of client
                    }catch (IOException e){
                        e.printStackTrace();
                    }
                    break;
                }//end of upload case



//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//


                case "LIST": {
                    String textToTheClient; // return to the client the files name like this :  FILELIST : NAME1:NAME2:NAME3...
                    PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);
                    String path = SentenceServerMulti.PathOfTheProject + "\\" +SentenceServerMulti.pathUpload ;
                    System.out.println(path);
                    File f = new File(path);
                    File[] listOfFile = f.listFiles();
                    String listForTheClient ="";
                    for (int i = 0; i < listOfFile.length; i++) {
                        if (listOfFile[i].isFile()) {
                            textToTheClient = listOfFile[i].getName();

                            outToClient.println(textToTheClient);
                            System.out.println(textToTheClient + "\n");
                            listForTheClient+=textToTheClient +" ";

                        }
                    }
                    SentenceServerMulti.logger.info(listForTheClient);
                    break;
                }

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

                case "FILELIST" :{
                    PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);
                    outToClient.println(FileVersionHash.keySet()); // need to send the version(digest and data time )  of the files
                    break;
                }

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

                //this case lock file - if client start it - it connect other server and ask to lock their file
                //if server start it , it lock(or not) the file for this server and send a msg to server call him .
                case "LOCK" : {
                    //get the file name from the client
                    try {
                        String FileName = AnswareFrom.nextLine();
                        String WhoCallMe = AnswareFrom.nextLine();////////// client or server call me ?
                        String ipofclient= AnswareFrom.nextLine();
                        PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);


                        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        //else - if the IP of WhoCallMe is not server IP , so it is the client call , in this case he need to check with all the server that connect.
                         if (WhoCallMe.equals("client")) {
                             SentenceServerMulti.logger.info("Client call me - I am the first server connect! ");
                             LockState = FileLockHash.containsKey(FileName); ///if the file contains , so its locked already
                             fileExist = FileVersionHash.containsKey(FileName); //if the file have version so it upload already

                             int counterOfservers = 0;

                             //locks here ---------
                             if (fileExist && LockState == false) {
                                 SentenceServerMulti.logger.info("The file exists and is not currently locked  ");
                                 FileLockHash.put(FileName, ipofclient);

                                 SentenceServerMulti.logger.info("LOCK : Return OK to the client");
                                 outToClient.println("OK");
                             } else if (!fileExist || LockState) {

                                 SentenceServerMulti.logger.info("LOCK : Send Error to the client ");
                                 outToClient.println("ERROR");
                             }
                         }//END OF THE CLIENT CASE
                    }catch (IOException e){
                        System.out.println("problem in Lock case");
                    }

                    System.out.println("LOCK HASH MAP :" + FileLockHash);
                    break;
                }




//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//


                case "UNLOCK" : {
                    try {
                        String FileName = AnswareFrom.nextLine();
                        String WhoCallMe = AnswareFrom.nextLine();////////// client or server call me ?
                        String ipofclient = AnswareFrom.nextLine();
                        PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);
                        // String userIp = clientSock.getInetAddress().toString();
                        BufferedReader bufferedReader = null;
                        boolean LockState = FileLockHash.containsKey(FileName); //state of file - unlock or not
                        boolean fileExist = FileVersionHash.containsKey(FileName);

                        // System.out.println("LockState "+ LockState + "fileExist :" +fileExist  );

                        if (WhoCallMe.equals("client")) {
                            SentenceServerMulti.logger.info("UNLOCK : client call me !!");
                            int counterOfservers = 0;
                            if (fileExist && LockState) { // if the file exist and the file is already  locked .
                                if (ipofclient.equals(FileLockHash.get(FileName))) { // check who locked that file- if the same user he can unlock it
                                    //lock the file in this server
                                    SentenceServerMulti.logger.info("UNLOCK : OK ");
                                    FileLockHash.remove(FileName);
                                    outToClient.println("OK");
                                    System.out.println(FileLockHash);
                                } else {
                                    SentenceServerMulti.logger.info("UNLOCK : the file locked by somone else .");
                                    outToClient.println("ERROR");
                                }
                            } else if (!fileExist) {
                                SentenceServerMulti.logger.info("UNLOCK : The file doesnt exist ! ");
                                outToClient.println("ERROR");
                            }
                            else if(!LockState){
                                SentenceServerMulti.logger.info("UNLOCK : The file does not locked yet , you cant unlock it  ! ");
                                outToClient.println("ERROR");
                            }
                        }
                    }catch (IOException e){
                        e.printStackTrace();
                    }

                    System.out.println(FileLockHash);
                    break;
                }




//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

                case "GETVERSION" : {

                    String Filename = AnswareFrom.nextLine();
                    String Version = "";
                    PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);

                    //check if the file is saved in the path
                    String path = SentenceServerMulti.PathOfTheProject +"\\"+ SentenceServerMulti.pathUpload;
                    File folder = new File(path);
                    File[] listOfFile = folder.listFiles();

                    boolean bool = false;

                    for (int i = 0; i < listOfFile.length; i++) {
                        if (listOfFile[i].isFile()) {
                            if(listOfFile[i].getName().equals(Filename)){ // if the file exist
                                bool= true;
                                break;
                            }
                            else{
                                //THE FILE DOESNT EXIST
                            }
                        }
                    }

                    if(bool){
                        outToClient.println("OK");
                        String data = FileVersionHash.get(Filename).toString();
                        outToClient.println(data); //return the version of this file to the client
                        if(FileLockHash.containsKey(Filename)){
                            String whoLockedTheFile = FileLockHash.get(Filename);
                            outToClient.println(whoLockedTheFile);
                        }
                        SentenceServerMulti.logger.info("VERSION :OK -" + FileVersionHash.get(Filename).toString());
                    }
                    else{
                        outToClient.println("ERROR"); // the file probebly dosnt exist
                        outToClient.println("File Not exist!"); //return the version of this file to the client
                        SentenceServerMulti.logger.info("VERSION : ERROR - File not exist");
                    }

                    // VERSION digest datetime The line begins with VERSION (capitalization isn’t important) followed by one
                    // space. It’s followed by a version hash digest in hexadecimal format, a space, and a timestamp in ISO
                    // 8601 long date time format (e.g. 2021-10-29T08:27:22Z). The line ends with a new line character.

                    break;
                }

                default: {
                    break;
                }
            }
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

        } catch (IOException e) {
            System.out.println("Error in communication.  Closing.\n");
            SentenceServerMulti.logger.info("Error in communication.  Closing.\n");
            e.printStackTrace();
        }
        finally {
            //System.out.println("Finished and closed on " + clientSock.getRemoteSocketAddress().toString());
            try { clientSock.close(); } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return;
    }

}