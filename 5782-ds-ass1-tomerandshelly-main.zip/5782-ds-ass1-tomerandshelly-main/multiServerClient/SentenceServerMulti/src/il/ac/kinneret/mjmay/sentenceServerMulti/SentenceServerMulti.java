package il.ac.kinneret.mjmay.sentenceServerMulti;

import org.apache.commons.codec.digest.DigestUtils;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.PublicKey;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * A class for a multithreaded sentence server. It receives a sentence, changes it to upper case, counts the letters
 * and returns the modified sentence and its length to the client.
 */
public class SentenceServerMulti {

	private static ServerSocket serverSocket;
	public TextArea area;
	public static String pathUpload;
	public static Logger logger;
	public static Logger logger2;
	public static FileHandler fh;
	public static String [] IPOfServers;
	public  static int portNum;
	public static ArrayList<String> listOfServersConnected = null;
	public static ArrayList<String> ListConfigurationServer;
	public static InetAddress address;
	public static File fileProjectServer = new File("");
	public static String PathOfTheProject = fileProjectServer.getAbsolutePath(); //the path of the project
	public static String fileUpload ="" ;
	final static String PATH_LOGGER_SERVER="\\MyLogHandler.log";
	final static String PATH_CONFIGURATION_SERVER = "\\configureServer.txt";

	public SentenceServerMulti() {

		JFrame jframServer = new JFrame("Server Frame"); // Declaring the frame object and designing the GUI
		jframServer.setLayout(new BoxLayout(jframServer.getContentPane(), BoxLayout.Y_AXIS));
		jframServer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//text
		area=new TextArea();
		area.setBounds(0,0,400,400);
		area.setBackground(Color.LIGHT_GRAY);
		area.setFont(new Font("Ariel", Font.BOLD, 15));
		area.setText("Welcome to Server!!! \n\n");


		//add to fram
		jframServer.add(area);
		jframServer.setSize(400,450);
		jframServer.setLayout(null);
		jframServer.setVisible(true);
	}


	/**
	 * Gets the user to select an IP address to listen on from the list of local ones.
	 *
	 * @return The selected IP address
	 */
	public static InetAddress selectIPAddress()
	{
		// get the local IPs
		Vector<InetAddress> addresses = getLocalIPs();
		// see how many they are

		System.out.println("Choose an IP address to listen on:");
		for (int i = 0; i < addresses.size(); i++)
		{
			// show it in the list
			System.out.println(i + ": " + addresses.elementAt(i).toString());
		}

		BufferedReader brIn = new BufferedReader(new InputStreamReader(System.in));
		int choice = -1;

		while ( choice < 0 || choice >= addresses.size())
		{
			System.out.print(": ");
			try {
				String line = brIn.readLine();
				choice = Integer.parseInt(line.trim());
			}
			catch (Exception ex) {
				System.out.print("Error parsing choice\n: ");
			}
		}

		return addresses.elementAt(choice);

	}

	public static Vector<InetAddress> getLocalIPs()
	{
		// make a list of addresses to choose from
		// add in the usual ones
		Vector<InetAddress> adds = new Vector<InetAddress>();
		try {
			adds.add(InetAddress.getByAddress(new byte[] {0, 0, 0, 0}));
			adds.add(InetAddress.getByAddress(new byte[] {127, 0, 0, 1}));
		} catch (UnknownHostException ex) {
			// something is really weird - this should never fail
			System.out.println("Can't find IP address 0.0.0.0: " + ex.getMessage());
			ex.printStackTrace();
			return adds;
		}

		try {
			// get the local IP addresses from the network interface listing
			Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();

			while ( interfaces.hasMoreElements() )
			{
				NetworkInterface ni = interfaces.nextElement();
				// see if it has an IPv4 address
				Enumeration<InetAddress> addresses =  ni.getInetAddresses();
				while ( addresses.hasMoreElements())
				{
					// go over the addresses and add them
					InetAddress add = addresses.nextElement();
					// make sure it's an IPv4 address
					if (!add.isLoopbackAddress() && add.getClass() == Inet4Address.class)
					{
						adds.addElement(add);
					}
				}
			}
		}
		catch (SocketException ex)
		{
			// can't get local addresses, something's wrong
			logger.info("Can't get network interface information: " + ex.getLocalizedMessage());
		}
		return adds;
	}





	/**
	 * Runs the multithreaded sentence server.
	 * @param args The parameters for the server.  Should be two parameters - the IP address and port to listen on.
	 */
	public static void main(String[] args) throws IOException {

		///log file :
		try {
			logger = Logger.getLogger("myLogHandler");
			fh = new FileHandler(PathOfTheProject + PATH_LOGGER_SERVER);
			logger.addHandler(fh);
			SimpleFormatter formatter = new SimpleFormatter();
			fh.setFormatter(formatter);
			logger.info("My Log Handler ");
		}catch (SecurityException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}

		///log file :
		try {
			logger2 = Logger.getLogger("myLogServer");
			fh = new FileHandler(PathOfTheProject + PATH_LOGGER_SERVER);
			logger2.addHandler(fh);
			SimpleFormatter formatter = new SimpleFormatter();
			fh.setFormatter(formatter);
			logger2.info("My Log server : ");
		}catch (SecurityException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}


		//the file of configurationServer include the path , port , ipServer1 , ipServer2, ipServer3... the list include this too .
		 ListConfigurationServer = new ArrayList<>();
		//(1)path of sending file , (2)for port address
		String[] dataArr=new String[2]; //--1)path of sending file , 2)for port address



		//write to the array list the values of uploaa path  , port , ipOfServer , ipOfServer , ipOfServer ..
		try {
			File myObj = new File(PathOfTheProject + PATH_CONFIGURATION_SERVER);
			BufferedReader bufferedReader= new BufferedReader(new FileReader(myObj));
			String line = bufferedReader.readLine();
			while (line != null ){
				ListConfigurationServer.add(line);
				line = bufferedReader.readLine();
			}
			bufferedReader.close();

			//save the path and port
			dataArr[0] = ListConfigurationServer.get(0); //path
			dataArr[1] =ListConfigurationServer.get(1); //port

		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			logger.info("An error occurred.");

			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		 address = selectIPAddress();
		portNum = Integer.parseInt(dataArr[1]);
		pathUpload = dataArr[0];
		fileUpload ="//"+dataArr[0]+"//";



		//the server that connect now saved in an array list , LOCK UNLOCK UPLOAD VERSION , USE IT .
		SentenceServerMulti.listOfServersConnected = new ArrayList<String>();//list that contain all the server thet connect now
		//array of servers ip
		SentenceServerMulti.IPOfServers =new String[SentenceServerMulti.ListConfigurationServer.size()- 2]; // minus the UploadPath and port (first two lines in the configuration file ) .
		int j =0 ;



		String line = "";
		Listener listener = null;
	    BufferedReader brIn = new BufferedReader(new InputStreamReader(System.in));
		while (true) {
		//	SentenceServerMulti.Sync(SentenceServerMulti.listOfServersConnected);
			// open a socket on the port

			ServerSocket serverSock = null;
			//String IP;
			try {
				serverSock = new ServerSocket(portNum,10,address);
				//IP = serverSocket.getInetAddress().toString();
				listener = new Listener(serverSock);
				listener.start(); // Run of listener start
			} catch (IOException e) {

				e.printStackTrace();
			}

			logger.info(address + " Started to listen. ");

			try {
				do {
					line = brIn.readLine();
				} while (!line.equalsIgnoreCase("stop"));
				// user asked to stop
				listener.interrupt();
 				serverSock.close();
				logger2.info("Stopped listening.  To quit, enter \"quit\".  To resume listening, enter \"resume\": ");

				do {
					line = brIn.readLine();
				} while (!line.equalsIgnoreCase("quit") && !line.equalsIgnoreCase("resume"));

				if (line.equals("resume")) {
					continue;
				} else if (line.equals("quit")) {
					break;
				}

			} catch (IOException ex)
			{
				// this shouldn't happen, just quit
				listener.interrupt();
				break;
			}
		}
		logger2.info("Goodbye.\n");
		return;
	}






}//end of class
