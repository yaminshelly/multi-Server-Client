Names of presenters : 
Tomer Revivo - ID number : 204470892 , GitHub: TomerRevivo 
Shelly Revivo -ID number : 315661884  , GitHub: yaminshelly

credit : Part of the assignment was taken from lecture Michael Mey from class exercises

# Assignment2-File-Server-Sync


## Division of labor and working time

Shelly : 
Server synchronization - 30
Get Version - 20
Version to all - 7
Upload - 40

Tomer:
Lock - 30
Unlock - 20
Download - 8
List - 5

Note :
The hours are about failed attempts / ideas / tests/ debugging and more. Until the mission is successful. 

____________________________________________________________________________________________________________________________________________________________________

## Instructions for compiling the source code for both the client and server programs

## server : 

if you dont use the jar and you want to compile the server : 
The server uses org.apache.commons.codec.digest.DigestUtils so it is necessary to add the directory before compiling. 
File -> project structure  -> Moduels -> Dependencies - > (+)(plus) - > jar or directory - > ...\multiServerClient\commons-codec-1.11

this folder is the library. 

Run it from the intellij. 

## client 
run the client. 


____________________________________________________________________________________________________________________________________________________________________

###### Instructions for running the client and server programs + Documentation of the client and server configuration file
## client : 
1) Change the IP of the servers in the configuration file located in the folder:  ....\multiServerClient\SentenceClient\FileConfigurationCsv.csv
   Add three servers by name:serverOne, serverTwo, serverThree.
   Add a suitable ip to each server.
   Save the configuration file as csv (comma delimited).
3)Enter to jar file path  is :...\multiServerClient\SentenceClient\classes\artifacts\SentenceClient_jar


## server :
1)Change the IP of the servers in the configuration file locatef in the folder : ...\multiServerClient\SentenceServerMulti\classes\artifacts\SentenceServerMulti_jar\configureServer.txt
the configuration file of the server include server port and the file root directory to store file, and all the ip addresses of the servers we use in run time . 

2)Running the server through jar:
**Conference to cmd.
**type cd  ...\SentenceServerMulti\classes\artifacts\SentenceServerMulti_jar
**type: java -jar SentenceServerMulti.jar

3)log file for the server- >  path : ...\multiServerClient\SentenceServerMulti\MyLogFileServer.log 
4)log file for the handler (worker) -> path : ...\multiServerClient\SentenceServerMulti\MyLogHandler.log

_____________________________________________________________________________________________________________________________________________

#### Documentation of how thread safety is ensured : 

Use a synchronized and thread safe collection-  ConcurrentHashMap - for the file
index.
When server is up, it synchronized with the other server connect now , take the files name, version , and lock state and save it in a ConcurrentHashMaps .

every client has a name that you can change before it up , in the configuration file of the client  . 

#### Documentation of how client identity is used in global locking and unlocking

The lock ConcurrentHashMaps save the name of the file with the ip of the client so no one can unlock file that locked already by someone else.
when file locked, it locked the file on all the server connect , when one more server connect it synchronize the locking , so all server is the same all the time . 
The same about unlock . 













