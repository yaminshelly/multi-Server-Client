package il.ac.kinneret.mjmay.sentenceServerMulti;

import org.apache.commons.codec.digest.DigestUtils;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.PublicKey;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * A class for a multithreaded sentence server. It receives a sentence, changes it to upper case, counts the letters
 * and returns the modified sentence and its length to the client.
 */
public class SentenceServerMulti {

	private static ServerSocket serverSocket;
	public TextArea area;
	public static String pathUpload;
	public static Logger logger;
	public static Logger logger2;
	public static FileHandler fh;
	public static String [] IPOfServers;
	public  static int portNum;
	public static ArrayList<String> listOfServersConnected = null;
	public static ArrayList<String> ListConfigurationServer;
	public static InetAddress address;
	private static boolean connected = false;
	static Socket socket;
	public static File fileProjectServer = new File("");
	public static String PathOfTheProject = fileProjectServer.getAbsolutePath(); //the path of the project
	public static String fileUpload ="";
	final static String fileTemporary = "\\TemporaryFolder\\";
	final static String PATH_LOGGER_SERVER="\\MyLogHandler.log";
	final static String PATH_CONFIGURATION_SERVER = "\\configureServer.txt";

	public SentenceServerMulti() {

		JFrame jframServer = new JFrame("Server Frame"); // Declaring the frame object and designing the GUI
		jframServer.setLayout(new BoxLayout(jframServer.getContentPane(), BoxLayout.Y_AXIS));
		jframServer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//text
		area=new TextArea();
		area.setBounds(0,0,400,400);
		area.setBackground(Color.LIGHT_GRAY);
		area.setFont(new Font("Ariel", Font.BOLD, 15));
		area.setText("Welcome to Server!!! \n\n");


		//add to fram
		jframServer.add(area);
		jframServer.setSize(400,450);
		jframServer.setLayout(null);
		jframServer.setVisible(true);
	}


	public SentenceServerMulti(int port){

	}

	public static void checkServerConnectedNow(){
		//the server that connect now saved in an array list , LOCK UNLOCK UPLOAD VERSION , USE IT .
		SentenceServerMulti.listOfServersConnected = new ArrayList<String>();//list that contain all the server thet connect now
		//array of servers ip
		SentenceServerMulti.IPOfServers =new String[SentenceServerMulti.ListConfigurationServer.size()- 2]; // minus the UploadPath and port (first two lines in the configuration file ) .
		int j =0 ;
	//	SentenceServerMulti.logger.info("Check servers connected now");
		//this for move on all the ip of server in the file configuration and check who connect now
		for (int i = 2 ; i < SentenceServerMulti.ListConfigurationServer.size() ; i++) {
			SentenceServerMulti.IPOfServers[j] = SentenceServerMulti.ListConfigurationServer.get(i); //save the ip of servers in an array
			//check which of the server connect here
			try {
				if(SentenceServerMulti.checkWhoServerConnect(SentenceServerMulti.IPOfServers[j])){
					if(!SentenceServerMulti.address.toString().equals("/"+SentenceServerMulti.IPOfServers[j])){
						SentenceServerMulti.listOfServersConnected.add(SentenceServerMulti.IPOfServers[j]);
					}
					else {
						///
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			j++;
		}
	}

	/**
	 * Gets the user to select an IP address to listen on from the list of local ones.
	 *
	 * @return The selected IP address
	 */
	public static InetAddress selectIPAddress()
	{
		// get the local IPs
		Vector<InetAddress> addresses = getLocalIPs();
		// see how many they are

		System.out.println("Choose an IP address to listen on:");
		for (int i = 0; i < addresses.size(); i++)
		{
			// show it in the list
			System.out.println(i + ": " + addresses.elementAt(i).toString());
		}

		BufferedReader brIn = new BufferedReader(new InputStreamReader(System.in));
		int choice = -1;

		while ( choice < 0 || choice >= addresses.size())
		{
			System.out.print(": ");
			try {
				String line = brIn.readLine();
				choice = Integer.parseInt(line.trim());
			}
			catch (Exception ex) {
				System.out.print("Error parsing choice\n: ");
			}
		}

		return addresses.elementAt(choice);

	}

	public static Vector<InetAddress> getLocalIPs()
	{
		// make a list of addresses to choose from
		// add in the usual ones
		Vector<InetAddress> adds = new Vector<InetAddress>();
		try {
			adds.add(InetAddress.getByAddress(new byte[] {0, 0, 0, 0}));
			adds.add(InetAddress.getByAddress(new byte[] {127, 0, 0, 1}));
		} catch (UnknownHostException ex) {
			// something is really weird - this should never fail
			System.out.println("Can't find IP address 0.0.0.0: " + ex.getMessage());
			ex.printStackTrace();
			return adds;
		}

		try {
			// get the local IP addresses from the network interface listing
			Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();

			while ( interfaces.hasMoreElements() )
			{
				NetworkInterface ni = interfaces.nextElement();
				// see if it has an IPv4 address
				Enumeration<InetAddress> addresses =  ni.getInetAddresses();
				while ( addresses.hasMoreElements())
				{
					// go over the addresses and add them
					InetAddress add = addresses.nextElement();
					// make sure it's an IPv4 address
					if (!add.isLoopbackAddress() && add.getClass() == Inet4Address.class)
					{
						adds.addElement(add);
					}
				}
			}
		}
		catch (SocketException ex)
		{
			// can't get local addresses, something's wrong
			logger.info("Can't get network interface information: " + ex.getLocalizedMessage());
		}
		return adds;
	}



	//this func return true or false if server from the list connect now !
	public static boolean checkWhoServerConnect(String ipOfServer) throws IOException {
		boolean b = true;
		try{
			Socket ss = new Socket(ipOfServer, portNum);
			ss.close();
		}catch(Exception e) {
			b = false;
		}
		return b;
	}



	//this function make syncronize , get filesfrom all the server , compare them , and save to the hash map the most up-to-date file
	public static void Sync(ArrayList<String> listOfServerConnected) throws IOException {

		String FileName = "";
		String Digest = "";
		String TimeStamp = "";
		String whoLockTheFile = "";
		String[][] detailsSave;


		if (listOfServerConnected != null) {
			//Every server connected , have list of files with details : file name | data time | digest | Who lock this file
			ArrayList<String>[] ArrlistOfFiles = new ArrayList[listOfServerConnected.size()];
			SentenceServerMulti.logger2.info("\nSync start now !\n");

			for (String ipOfServer : SentenceServerMulti.listOfServersConnected) {

				try {
					Socket socket = new Socket(ipOfServer, SentenceServerMulti.portNum);
					//send a msg to the server :
					DataOutputStream outToServer = new DataOutputStream(socket.getOutputStream());
					PrintWriter pw1 = new PrintWriter(socket.getOutputStream(), true);
					outToServer.writeBytes("FILELIST\n");
					SentenceServerMulti.logger.info("send FILELIST  to the server " + ipOfServer + ".");

					//Scanner to get information from the server
					Scanner scanner1 = new Scanner(socket.getInputStream());
					String namesOfFiles = scanner1.nextLine(); // get the files name in the other server connect now
					//String FileLockHash = scanner1.nextLine(); //
					namesOfFiles = namesOfFiles.substring(1, namesOfFiles.length() - 1); //remove first and last char
					namesOfFiles = namesOfFiles.replaceAll("\\s", "");//remove the spaces
					String[] namesOfFilesArray = namesOfFiles.split(",");
					SentenceServerMulti.logger.info("The files in "+ipOfServer +" server are: "+ namesOfFiles);

					//check if work now


					String [][] details = new String[namesOfFilesArray.length][4];
					for (int i =0 ; i< namesOfFilesArray.length ; i++) {
						socket.close();
						socket = new Socket(ipOfServer, SentenceServerMulti.portNum);
						outToServer = new DataOutputStream(socket.getOutputStream());
						scanner1 = new Scanner(socket.getInputStream());
						pw1 = new PrintWriter(socket.getOutputStream(), true);
						details[i][0] = namesOfFilesArray[i];
						System.out.println(namesOfFilesArray[i]);
						outToServer.writeBytes("GETVERSION1\n");
						pw1.println(namesOfFilesArray[i]);

						String digestDateTime = scanner1.nextLine();
						System.out.println(digestDateTime);
						digestDateTime = digestDateTime.replaceAll("\\s", "");//remove the spaces
						String[] digestDataTimeArr = digestDateTime.split(",");
						String digest = digestDataTimeArr[0];
						details[i][1] = digest;
						System.out.println(digestDataTimeArr[1]);
						String dateTime = digestDataTimeArr[1];
						details[i][2] = dateTime;
						String whoLockFile = "";
						try{
							whoLockFile= scanner1.nextLine();
						}catch (Exception e){
							e.printStackTrace();
						}
						details[i][3] = whoLockFile;


						if(HandleClientThread.FileVersionHash.containsKey(details[i][0])){
							//compare the data time
							String date1 = HandleClientThread.FileVersionHash.get(details[i][0]).toString();
							date1.replaceAll("\\s", "");//remove the spaces
							String[] dateAfterChange =date1.split(",");
							String Date = dateAfterChange[1];
							String data2 = details[i][2];   ///for example : date2 2021-12-30T00:40:11Z, Date: 2021-12-30T02:37:47Z
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");

							SentenceServerMulti.logger.info("The server compare the version and decide what to choose. ");

							//if one of the servers have the same file , but newer , we take the new file and download it , we update the hash map of the files .  .
							if(sdf.parse(data2).before(sdf.parse(Date))){
								HandleClientThread.FileVersionHash.replace(details[i][0] ,details[i][1] +"," + details[i][2]);
								if(HandleClientThread.FileLockHash.containsKey(details[i][0])){
									HandleClientThread.FileLockHash.replace(details[i][0] , details[i][3]);
								}

								//Download the file from the server change the file that exist here .
								socket = new Socket(ipOfServer, SentenceServerMulti.portNum);
								outToServer = new DataOutputStream(socket.getOutputStream());
								scanner1 = new Scanner(socket.getInputStream());
								pw1 = new PrintWriter(socket.getOutputStream(), true);

								outToServer.writeBytes("DOWNLOAD\n");
								pw1.println(namesOfFilesArray[i]);
								String uploadFile = scanner1.nextLine(); // get the byte of the file from other server .


								//path to save the file should be here- need to be in gui (the saving ) .
								FileOutputStream fos = new FileOutputStream(SentenceServerMulti.PathOfTheProject + SentenceServerMulti.fileUpload + namesOfFilesArray[i]);
								BufferedOutputStream bos = new BufferedOutputStream(fos);
								//Upload the file - saving this file to a path temporary folder on the server//////////////////////
								byte[]filebytes = Base64.getDecoder().decode(uploadFile);
								fos.write(filebytes);

							}
						}


						//the files new for this server
						else{
							HandleClientThread.FileVersionHash.put(details[i][0],details[i][1]+","+HandleClientThread.DateTime());
							if(!details[i][3].equals("")){
								//something about lock hash map
								if(HandleClientThread.FileLockHash.containsKey(details[i][0])){
									HandleClientThread.FileLockHash.replace(details[i][0], details[i][3]);
								}
								else {
									HandleClientThread.FileLockHash.put(details[i][0], details[i][3]);
								}
							}
							//download the file to this server
							//socket.close();
							socket = new Socket(ipOfServer, SentenceServerMulti.portNum);
							outToServer = new DataOutputStream(socket.getOutputStream());
							scanner1 = new Scanner(socket.getInputStream());
							pw1 = new PrintWriter(socket.getOutputStream(), true);

							outToServer.writeBytes("DOWNLOAD\n");
							pw1.println(namesOfFilesArray[i]);
							String uploadFile = scanner1.nextLine(); // get the byte of the file from other server .


							//path to save the file should be here- need to be in gui (the saving ) .
							FileOutputStream fos = new FileOutputStream(SentenceServerMulti.PathOfTheProject + SentenceServerMulti.fileUpload + namesOfFilesArray[i]);
							BufferedOutputStream bos = new BufferedOutputStream(fos);
							//Upload the file - saving this file to a path temporary folder on the server//////////////////////
							byte[]filebytes = Base64.getDecoder().decode(uploadFile);
							fos.write(filebytes);




							if(scanner1.nextLine().equals("OK")){
								System.out.println("sync successfully ");
								SentenceServerMulti.logger.info("sync successfully");
							}

						}

					}//end of for namrs of files

					detailsSave= details;

				}catch (Exception e){
					e.printStackTrace();
				}
				//socket.close();
			}
			SentenceServerMulti.logger2.info("Sync completed, the server hash map lock: " + HandleClientThread.FileLockHash + " the server hash map version file : " + HandleClientThread.FileVersionHash);
			SentenceServerMulti.logger.info("Sync completed, the server hash map lock: " + HandleClientThread.FileLockHash + " the server hash map version file : " + HandleClientThread.FileVersionHash);
		}
	}



	/**
	 * Runs the multithreaded sentence server.
	 * @param args The parameters for the server.  Should be two parameters - the IP address and port to listen on.
	 */
	public static void main(String[] args) throws IOException {

		///log file :
		try {
			logger = Logger.getLogger("myLogHandler");
			fh = new FileHandler(PathOfTheProject + PATH_LOGGER_SERVER);
			logger.addHandler(fh);
			SimpleFormatter formatter = new SimpleFormatter();
			fh.setFormatter(formatter);
			logger.info("My Log Handler ");
		}catch (SecurityException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}

		///log file :
		try {
			logger2 = Logger.getLogger("myLogServer");
			fh = new FileHandler(PathOfTheProject + PATH_LOGGER_SERVER);
			logger2.addHandler(fh);
			SimpleFormatter formatter = new SimpleFormatter();
			fh.setFormatter(formatter);
			logger2.info("My Log server : ");
		}catch (SecurityException e){
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}


		//the file of configurationServer include the path , port , ipServer1 , ipServer2, ipServer3... the list include this too .
		 ListConfigurationServer = new ArrayList<>();
		//(1)path of sending file , (2)for port address
		String[] dataArr=new String[2]; //--1)path of sending file , 2)for port address



		//write to the array list the values of uploaa path  , port , ipOfServer , ipOfServer , ipOfServer ..
		try {
			File myObj = new File(PathOfTheProject + PATH_CONFIGURATION_SERVER);
			BufferedReader bufferedReader= new BufferedReader(new FileReader(myObj));
			String line = bufferedReader.readLine();
			while (line != null ){
				ListConfigurationServer.add(line);
				line = bufferedReader.readLine();
			}
			bufferedReader.close();

			//save the path and port
			dataArr[0] = ListConfigurationServer.get(0); //path
			dataArr[1] =ListConfigurationServer.get(1); //port

		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			logger.info("An error occurred.");

			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		 address = selectIPAddress();
		portNum = Integer.parseInt(dataArr[1]);
		pathUpload = dataArr[0];
		fileUpload = "\\"+dataArr[0]+"\\";




		//the server that connect now saved in an array list , LOCK UNLOCK UPLOAD VERSION , USE IT .
		SentenceServerMulti.listOfServersConnected = new ArrayList<String>();//list that contain all the server thet connect now
		//array of servers ip
		SentenceServerMulti.IPOfServers =new String[SentenceServerMulti.ListConfigurationServer.size()- 2]; // minus the UploadPath and port (first two lines in the configuration file ) .
		int j =0 ;
		SentenceServerMulti.logger.info("Check servers connected now");
		//this for move on all the ip of server in the file configuration and check who connect now
		for (int i = 2 ; i < SentenceServerMulti.ListConfigurationServer.size() ; i++) {
			SentenceServerMulti.IPOfServers[j] = SentenceServerMulti.ListConfigurationServer.get(i); //save the ip of servers in an array
			//check which of the server connect here
			try {
				if(SentenceServerMulti.checkWhoServerConnect(SentenceServerMulti.IPOfServers[j])){
					if(!SentenceServerMulti.address.toString().equals("/"+SentenceServerMulti.IPOfServers[j])){
						SentenceServerMulti.listOfServersConnected.add(SentenceServerMulti.IPOfServers[j]);
					}
					else {
						///
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			j++;
		}

		if(SentenceServerMulti.listOfServersConnected.size() == 0 ){
			SentenceServerMulti.logger.info("There are no connected servers ! \n ");
		}
		else {

			String ServerConnect = "";
			//print to the logger the server who connect now !
			for (String s : SentenceServerMulti.listOfServersConnected) {
				ServerConnect += s + "  ";
			}
			SentenceServerMulti.logger.info("List Of server connect : " +ServerConnect);
		}



		String line = "";
		Listener listener = null;
	    BufferedReader brIn = new BufferedReader(new InputStreamReader(System.in));
		while (true) {
			SentenceServerMulti.Sync(SentenceServerMulti.listOfServersConnected);
			// open a socket on the port

			ServerSocket serverSock = null;
			//String IP;
			try {
				serverSock = new ServerSocket(portNum,10,address);
				//IP = serverSocket.getInetAddress().toString();
				listener = new Listener(serverSock);
				listener.start(); // Run of listener start
			} catch (IOException e) {

				e.printStackTrace();
			}

			logger.info(address + " Started to listen. ");

			try {
				do {
					line = brIn.readLine();
				} while (!line.equalsIgnoreCase("stop"));
				// user asked to stop
				listener.interrupt();
 				serverSock.close();
				logger2.info("Stopped listening.  To quit, enter \"quit\".  To resume listening, enter \"resume\": ");
				logger.info("Stopped listening.  To quit, enter \"quit\".  To resume listening, enter \"resume\": ");
				do {
					line = brIn.readLine();
				} while (!line.equalsIgnoreCase("quit") && !line.equalsIgnoreCase("resume"));

				if (line.equals("resume")) {
					continue;
				} else if (line.equals("quit")) {
					break;
				}

			} catch (IOException ex)
			{
				// this shouldn't happen, just quit
				listener.interrupt();
				break;
			}
		}
		logger2.info("Goodbye.\n");
		logger.info("Goodbye.\n");
		return;
	}






}//end of class
