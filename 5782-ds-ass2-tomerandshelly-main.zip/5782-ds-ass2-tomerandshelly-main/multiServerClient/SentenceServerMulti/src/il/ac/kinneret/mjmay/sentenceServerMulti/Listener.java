package il.ac.kinneret.mjmay.sentenceServerMulti;

import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class Listener extends Thread{

    private ServerSocket serverSocket;
    static int i = 1;

    public Listener (ServerSocket socket){
        serverSocket = socket;
    }


    @Override
    public void run() {
        // start to listen on the server socket
        SentenceServerMulti sentenceServerMulti = new SentenceServerMulti();
        SentenceServerMulti.logger2.info("Listening on port :  " + serverSocket.getLocalPort() + "\n");
        SentenceServerMulti.logger.info("Listening on port :  " + serverSocket.getLocalPort() + "\n");

        while (!interrupted()) { //Check if thread sleep or wait
            try {
                //syncronize between the server connect now

                // get a new connection , waiting for event in the client or other server that connect
                Socket clientSocket = serverSocket.accept();

                //worker start to work here :
                 HandleClientThread clientThread = new HandleClientThread(clientSocket);
                 clientThread.start();

            } catch (Exception ex)
            {
                ex.printStackTrace();
            }
        }
        // we're done!
        SentenceServerMulti.logger2.info("Stopped listening.\n");
        SentenceServerMulti.logger.info("Stopped listening.\n");
        try {
            serverSocket.close();
        } catch (Exception ex)
        {
            //noting to do
        }
    }
}
