
package il.ac.kinneret.mjmay.sentenceServerMulti;
import org.apache.commons.codec.digest.DigestUtils;


import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import java.io.*;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

public class HandleClientThread extends Thread {
    // Create a HashMap object called capitalCities that will store String keys(NAME OF FILE)  and String values:
    public static ConcurrentHashMap FileVersionHash= new ConcurrentHashMap();  //<filename , digest+datatime>
    public static ConcurrentHashMap<String , String> FileLockHash= new ConcurrentHashMap<String , String>(); //< filename , ip >
    private Socket clientSock;
    private Socket socket1;
    private static boolean LockState ;
    private  static boolean fileExist;
    private      Scanner scanner1;
    /**
     * Initializes the server.
     * @param sock The client socket to handle.
     */
    public HandleClientThread(Socket sock)
    {
        super("HandleClientThread-" + sock.getRemoteSocketAddress().toString());
        this.clientSock = sock;
    }




    //this function return the digest of file, input : path of the file , output : the digest
    private static String Digest(String PathOfFile) throws IOException {
        File fileThatDownload = new File(PathOfFile);
        byte [] filesBytes = Files.readAllBytes(fileThatDownload.toPath());
        String sha256Hex = DigestUtils.sha256Hex(filesBytes);
        return sha256Hex;
    }
    //this function return the date and time
    public static String DateTime(){
        TimeZone tz = TimeZone.getTimeZone("Asia/Jerusalem");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"); // Quoted "Z" to indicate UTC, no timezone offset
        df.setTimeZone(tz);
        String nowAsISO = df.format(new Date()); //thas the data time
        return nowAsISO;
    }

    //this function save the file into a path upload file in the server , it userd in the offer case, if the server decided to download the file .
    private static void saveFile( String FileName, Socket clientSock , String digestDataTime , String uploadFile) throws IOException{
        //path to save the file should be here- need to be in gui (the saving ) .
        FileOutputStream fos = new FileOutputStream(SentenceServerMulti.PathOfTheProject + SentenceServerMulti.fileUpload + FileName);
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        //Upload the file - saving this file to a path temporary folder on the server//////////////////////
        byte[]filebytes = Base64.getDecoder().decode(uploadFile);
        fos.write(filebytes);

        SentenceServerMulti.logger.info("\nThe file download succesfully! ");
        SentenceServerMulti.logger.info("\nThe file download succesfully! ");
        if(FileVersionHash.contains(FileName)){
            FileVersionHash.replace(FileName, digestDataTime);
        }
        else {
            FileVersionHash.put(FileName, digestDataTime);
            SentenceServerMulti.logger.info("The file " + FileName + " version " +digestDataTime);
        }

        System.out.println(FileVersionHash);
        SentenceServerMulti.logger.info("The file : " +FileName + ", version : "+ digestDataTime +"upload to this server");
    }





    /**
     * Runs the server
     * the run get command from the client or the other server that chosen to be first
     * the command are :
     * OFFER  - when one server ask other server to upload file
     * Download - when the client want to download a file or offer say download
     * Upload - when client want upload file (it upload to all servers )
     * lock file - client lock file if he want to upload another one with the same name
     * unlock
     * getversion - every file has a version
     * List - get the list of file that we have in the other server that connect now .
     */
    public void run()
    {

        try{
            // attach a buffered reader and print writer
            Scanner AnswareFrom = new Scanner(clientSock.getInputStream());
            String command = AnswareFrom.nextLine();
            SentenceServerMulti.logger.info("Get "+ command +" from " + clientSock.getInetAddress());
            DataOutputStream AnswareTo = new DataOutputStream(clientSock.getOutputStream());
            PrintWriter out =new PrintWriter(clientSock.getOutputStream());

            //check what the commanf that the client send :

            switch (command) {

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
                case "OFFER" :{

                    boolean LockFileByClient = false;
                    String digestDataTime = AnswareFrom.nextLine();
                    String FileName = AnswareFrom.nextLine();
                    String IpOfClient = AnswareFrom.nextLine();


                    System.out.println(FileLockHash);
                    System.out.println(FileVersionHash);


                    boolean fileExist = FileVersionHash.containsKey(FileName); // True - if the file has a version already
                    boolean fileLockQuestion =  FileLockHash.containsKey(FileName); //True - if the file locked already
                    if(fileExist && fileLockQuestion) {
                        LockFileByClient = FileLockHash.get(FileName).equals(IpOfClient);
                    }
                    // String version = scanner.nextLine();
                    if(!fileExist  || (fileExist && LockFileByClient)){
                        SentenceServerMulti.logger.info("\nThe file doesnt exist in this server ");
                        //download the file to the server
                        SentenceServerMulti.logger.info("\nSend DOWNLOAD to the client! ");
                        AnswareTo.writeBytes("DOWNLOAD\n");

                        try{
                            //values o send to the other server
                            //  AnswareTo.writeBytes(FileName+"\n");
                            //values that came from the otther server (in upload case)
                            String commandfromserverone =  AnswareFrom.nextLine();
                            if (commandfromserverone.equals("OK")) {
                                SentenceServerMulti.logger.info("OFFER : OK from main server");
                                String uploadFile = AnswareFrom.nextLine(); // get the byte of the file from other server .
                                //this function should save the send file into a upload path in the server  and save it in hash map version
                                saveFile(  FileName , clientSock ,digestDataTime , uploadFile);

                            } else if (commandfromserverone.equals("ERROR")){
                                SentenceServerMulti.logger.info("\nOFFER : ERROR from main server, dont download");
                            }
                        }catch (SocketException e) {
                            e.printStackTrace();
                        }
                    }
                    //the file exist and locked by another client .
                    else{
                        SentenceServerMulti.logger.info("\nOFFER : ERROR ");
                        AnswareTo.writeBytes("ERROR");
                    }
                    break;
                }
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//


                //Download case , this saving the file that send by client or another server
                case "DOWNLOAD": {

                    //Upload the file - saving this file to a path temporary folder on the server//////////////////////
                    PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);
                    String FileName = AnswareFrom.nextLine();
                    String pathToSaveTeFiles = SentenceServerMulti.PathOfTheProject+SentenceServerMulti.fileUpload+ FileName;
                    File file = new File(pathToSaveTeFiles);

                    String uploadFile;
                    byte[] filebyte= Files.readAllBytes(Paths.get(file.toString()));
                    uploadFile = Base64.getEncoder().encodeToString(filebyte);
                    outToClient.println(uploadFile);
                    outToClient.println("OK");
                    SentenceServerMulti.logger.info("DOWNLOWD : OK ");

                    break;
                }

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

                case "UPLOAD":
                {
                    InputStream is = clientSock.getInputStream();
                    PrintWriter printWriter = new PrintWriter(clientSock.getOutputStream(), true);
                    //get information from client
                    String FileName = AnswareFrom.nextLine();
                    String FileSizeString = AnswareFrom.nextLine();
                    int FileSize = Integer.parseInt(FileSizeString);
                    String WhoCallMe = AnswareFrom.nextLine();  // return the name :  client or server
                    String IpOfClient = AnswareFrom.nextLine();
                    String uploadFile = AnswareFrom.nextLine();
                    boolean TheFileIsLocked=FileLockHash.contains(FileName);
                    //String IpOfClient = clientSock.getInetAddress().toString();

                    String pathTempFolder = SentenceServerMulti.PathOfTheProject + SentenceServerMulti.fileTemporary;
                    boolean WhoLockTheFileQuestion=false;

                    //if the first server call me
                    if(WhoCallMe.equals("server")){
                        SentenceServerMulti.logger.info("server call me ! ");

                    }//end of server



                    //----------------------------------------------if the client call me (so I am the first server! )-------------------------------
                    else if(WhoCallMe.equals("client")){
                        SentenceServerMulti.logger.info("client call me !");
                        //check if the file exist
                        boolean fileExist = FileVersionHash.containsKey(FileName);

                        if(FileLockHash.containsKey(FileName)) {
                            WhoLockTheFileQuestion = FileLockHash.get(FileName).equals(IpOfClient); // if the client who upload the file is the same to who lock it so this value true .
                        }


                        //if the file exist and locked , and who locked it was not this client (who trying to upload the file)
                        if(fileExist && WhoLockTheFileQuestion==false){
                            SentenceServerMulti.logger.info("UPLOAD : ERROR - Server send Error to the client , cant upload the file ");
                            printWriter.println("ERROR");
                            break;
                        }

                        //if the file exist , and locked by the same client who want to upload it  OR if the file doesnt exist
                        //here the upload upload the file to this server(the first one )  to a temporary folder and ofer this file to another server connect now
                        else if((fileExist && WhoLockTheFileQuestion==true)|| (!fileExist)){

                            //Upload the file - saving this file to a path temporary folder on the server//////////////////////
                            FileOutputStream fos = new FileOutputStream(SentenceServerMulti.PathOfTheProject+SentenceServerMulti.fileTemporary + FileName); //to save the file in a path spcific
                            byte[]filebytes = Base64.getDecoder().decode(uploadFile);
                            fos.write(filebytes);


                            SentenceServerMulti.checkServerConnectedNow();//this function update the server connect now !
                            PrintWriter pw1;
                            int counterOfservers=0 ;
                            ///////////
                            //  send offer to all server connect now
                            for (String ipOfServer :SentenceServerMulti.listOfServersConnected) { //sent offer msg to all the server that connect now!
                                try {
                                    //connect to the server
                                    socket1 = new Socket(ipOfServer, SentenceServerMulti.portNum);
                                    SentenceServerMulti.logger.info("connect to server " + ipOfServer +".");
                                    //send a msg to the server :
                                    DataOutputStream outToServer = new DataOutputStream(socket1.getOutputStream());
                                    pw1 = new PrintWriter(socket1.getOutputStream(), true);
                                    outToServer.writeBytes("OFFER\n");

                                    pw1.println(Digest(SentenceServerMulti.PathOfTheProject+SentenceServerMulti.fileTemporary + FileName) +","+ DateTime()); //send the digest and data time that the file upload
                                    pw1.println(FileName); //THE NAME OF THE FILE TO THE OTHER SERVER
                                    pw1.println(IpOfClient);
                                    //  String version= FileVersionHash.get(FileName).toString();
                                    // pw1.println(version +"\n");

                                    SentenceServerMulti.logger.info("send OFFER "  +Digest(SentenceServerMulti.PathOfTheProject+SentenceServerMulti.fileTemporary + FileName) + " " + DateTime() + " to the server "+ ipOfServer +".");

                                    //Scanner to get information from the server
                                    Scanner scanner1 = new Scanner(socket1.getInputStream());


                                    String msgFromServer = scanner1.nextLine(); // ok or error msg from the other server
                                    switch (msgFromServer) { // download or error send from server 2
                                        case "DOWNLOAD":
                                            SentenceServerMulti.logger.info("the server " + ipOfServer + " send DOWNLOAD");
                                            counterOfservers ++;
                                            break;
                                        case "ERROR":
                                            SentenceServerMulti.logger.info("UPLOAD : ERROR - the server " + ipOfServer + " send ERROR ");
                                            counterOfservers = 0 ;
                                            break;
                                        default:
                                            break;
                                    }
                                }catch (SocketException e){

                                }
                            }

                            //download to all the server in the list
                            if(counterOfservers == SentenceServerMulti.listOfServersConnected.size()){
                                SentenceServerMulti.logger.info("All servers say DOWNLOAD");

                                //save the file into a upload files(this server ) by copy it from the temporary folder   :
                                File source = new File(SentenceServerMulti.PathOfTheProject+SentenceServerMulti.fileTemporary + FileName);
                                File dest = new File(SentenceServerMulti.PathOfTheProject + SentenceServerMulti.fileUpload + FileName);
                                InputStream inStream =new FileInputStream(source);
                                OutputStream outStream =new FileOutputStream(dest);
                                byte[] buffer1 = new byte[FileSize];

                                //enter this upload file to the hash map of version !
                                if(!FileVersionHash.containsKey(FileName)){
                                    FileVersionHash.put(FileName, Digest(SentenceServerMulti.PathOfTheProject+SentenceServerMulti.fileTemporary + FileName) +"," + DateTime());
                                }
                                else {
                                    FileVersionHash.replace(FileName, Digest(SentenceServerMulti.PathOfTheProject+SentenceServerMulti.fileTemporary + FileName) +"," +DateTime());
                                }

                                System.out.println(FileVersionHash);

                                if(counterOfservers >0) {

                                    for (String ipOfServer : SentenceServerMulti.listOfServersConnected) { //sent offer msg to all the server that connect now!
                                        try {
                                            //connect to the server
                                            socket1 = new Socket(ipOfServer, SentenceServerMulti.portNum);
                                            SentenceServerMulti.logger.info("connect to server " + ipOfServer + ".");
                                            //send a msg to the server :
                                            DataOutputStream outToServer = new DataOutputStream(socket1.getOutputStream());
                                            pw1 = new PrintWriter(socket1.getOutputStream(), true);
                                            outToServer.writeBytes("OKUPLOAD\n");
                                            pw1.println(FileName);
                                            pw1.println(Digest(SentenceServerMulti.PathOfTheProject+SentenceServerMulti.fileTemporary + FileName) +","+ DateTime()); //send the digest and data time that the file upload

                                            //the file sent here-->
                                            String path1 = SentenceServerMulti.PathOfTheProject + SentenceServerMulti.fileTemporary + FileName; //the path of the file we want to send to the server
                                            File file = new File(path1);
                                            File fileToDownload = new File(path1); //the file we want to send to the server
                                            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(fileToDownload));
                                            OutputStream os = socket1.getOutputStream();
                                            int fileSize = (int) fileToDownload.length();
                                            String uploadFile1;

                                            //send the file byte to the server
                                            byte[] filebyte = Files.readAllBytes(Paths.get(file.toString())); // Reaf the file from the path1
                                            uploadFile1 = Base64.getEncoder().encodeToString(filebyte);
                                            pw1.println(uploadFile1);

                                        } catch (Exception E) {
                                            E.printStackTrace();
                                        }

                                        //if all the server return download the other server download the file  - the first server send the file to the server and the server sould save the file
                                        //the first server say OK to the other servers, so they knoe they can save the file now


                                        // pw1 = new PrintWriter(socket1.getOutputStream(), true);
                                        // pw1.println("OK");


                                    }//end of the check if the list more than 1
                                }


                                int fileLength;
                                while ((fileLength = inStream.read(buffer1)) > 0){

                                    outStream.write(buffer1, 0, fileLength );

                                }
                                inStream.close();
                                outStream.close();
                                printWriter.println("OK");//////////////
                                SentenceServerMulti.logger.info("UPLOAD : OK");

                            }
                            else{
                                //the download did not comleate so the server return ERROR to the client who call him
                                printWriter.println("ERROR");////////////////////
                                SentenceServerMulti.logger.info("UPLOAD : ERROR - send error to the other servers, so they cant downoad the file now. ");
                            }
                        }
                    }//end of client
                    break;
                }//end of upload case


//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

                case "OKUPLOAD":{
                    try {
                        SentenceServerMulti.logger.info("OK UPLOAD from server One -SAVE THE FILE ");

                        String FileName = AnswareFrom.nextLine();
                        String digestDataTime = AnswareFrom.nextLine();
                        String uploadFile = AnswareFrom.nextLine(); // get the byte of the file from other server .
                        //this function should save the send file into a upload path in the server  and save it in hash map version
                        saveFile(  FileName , clientSock ,digestDataTime , uploadFile);

                        break;
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                }
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//


                case "LIST": {
                    String textToTheClient; // return to the client the files name like this :  FILELIST : NAME1:NAME2:NAME3...
                    PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);
                    String path = SentenceServerMulti.PathOfTheProject + "\\" +SentenceServerMulti.pathUpload ;
                    System.out.println(path);
                    File f = new File(path);
                    File[] listOfFile = f.listFiles();
                    String listForTheClient ="";
                    for (int i = 0; i < listOfFile.length; i++) {
                        if (listOfFile[i].isFile()) {
                            textToTheClient = listOfFile[i].getName();

                            outToClient.println(textToTheClient);
                            System.out.println(textToTheClient + "\n");
                            listForTheClient+= textToTheClient +" ";
                        }
                    }
                    SentenceServerMulti.logger.info("LIST :" + listForTheClient);
                    break;
                }

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

                case "FILELIST" :{
                    PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);
                    outToClient.println(FileVersionHash.keySet()); // need to send the version(digest and data time )  of the files
                    break;
                }

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

                //this case lock file - if client start it - it connect other server and ask to lock their file
                //if server start it , it lock(or not) the file for this server and send a msg to server call him .
                case "LOCK" : {
                    //get the file name from the client
                    try {
                        String FileName = AnswareFrom.nextLine();
                        String WhoCallMe = AnswareFrom.nextLine();////////// client or server call me ?
                        String ipofclient= AnswareFrom.nextLine();
                        System.out.println("ipofclient = " + ipofclient);
                        PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);
                        //String WhoCallMeIP = clientSock.getInetAddress().toString();

                        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        //if the server list contain the server that call him so it means that server call him and not client
                        //  so he uxt need to check the file lock it or not ,  and send a msg to the server who call him
                        if (WhoCallMe.equals("server")) {
                            SentenceServerMulti.logger.info("server call me !!");
                            BufferedReader bufferedReader = null;
                            boolean LockState = FileLockHash.contains(FileName);
                            boolean fileExist = FileVersionHash.containsKey(FileName);

                            //if the file exist and steal does not locked yet , lock it
                            if (fileExist && LockState == false) {
                                FileLockHash.put(FileName, ipofclient);
                                SentenceServerMulti.logger.info("LOCK : OK - success LOCK in the server who called !!");
                                outToClient.println("OK");
                                System.out.println("Lock : " + FileLockHash);
                            } else {//the file not exist or the file locked already
                                SentenceServerMulti.logger.info("LOCK : ERROR - Failed LOCK in the server who called !!");
                                outToClient.println("ERROR");
                            }
                        }


                        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                        //else - if the IP of WhoCallMe is not server IP , so it is the client call , in this case he need to check with all the server that connect.
                        else if (WhoCallMe.equals("client")) {
                            SentenceServerMulti.logger.info("Client call me - I am the first server connect! ");
                            LockState = FileLockHash.containsKey(FileName); ///if the file contains , so its locked already
                            fileExist = FileVersionHash.containsKey(FileName); //if the file have version so it upload already

                            int counterOfservers = 0;

                            //locks here ---------
                            if (fileExist && LockState == false) {
                                SentenceServerMulti.logger.info("Connect the other server that connect now and lock the file. ");

                                SentenceServerMulti.checkServerConnectedNow();//this function update the server connect now !
                                //the server send lock to all server he know .(listOfServersConnected list have all the ip that connect now)
                                for (String ipOfServer : SentenceServerMulti.listOfServersConnected) {
                                    try {
                                        //connect to the server
                                        Socket socket1 = new Socket(ipOfServer, SentenceServerMulti.portNum);
                                        SentenceServerMulti.logger.info("connect to server " + ipOfServer + ".");
                                        //send a msg to the server :
                                        DataOutputStream outToServer = new DataOutputStream(socket1.getOutputStream());
                                        outToServer.writeBytes("LOCK\n");
                                        PrintWriter pw1 = new PrintWriter(socket1.getOutputStream(), true);
                                        pw1.println(FileName); //THE NAME OF THE FILE TO THE OTHER SERVER
                                        pw1.println("server");
                                        pw1.println(ipofclient);

                                        SentenceServerMulti.logger.info("send Lock " + FileName + " to the server " + ipOfServer);

                                        //Scanner to get information from the server
                                        Scanner scanner1 = new Scanner(socket1.getInputStream());
                                        //msg from the server!
                                        String msgFromServer = scanner1.nextLine();
                                        switch (msgFromServer) {
                                            case "OK":
                                                SentenceServerMulti.logger.info("LOCK : OK - the server " + ipOfServer + " send OK for LOCK");
                                                counterOfservers++;
                                                break;
                                            case "ERROR":
                                                SentenceServerMulti.logger.info("LOCK : ERROR - the server " + ipOfServer + " send ERROR for LOCK");
                                                counterOfservers = 0;
                                                break;
                                            default:
                                                break;
                                        }
                                    } catch (SocketException e) {

                                    }
                                }
                                SentenceServerMulti.logger.info("The first server check if all the other server send ok");

                                if (counterOfservers == SentenceServerMulti.listOfServersConnected.size()) {
                                    SentenceServerMulti.logger.info("All servers say OK , lock the file " + FileName + " in this server");
                                    //lock the file in this server
                                    if (FileLockHash.containsKey(FileName)) {
                                        FileLockHash.replace(FileName, ipofclient);
                                    } else {
                                        FileLockHash.put(FileName, ipofclient);
                                    }
                                    SentenceServerMulti.logger.info("LOCK : OK - Return OK to the client");
                                    outToClient.println("OK");
                                } else {
                                    SentenceServerMulti.logger.info("LOCK : ERROR - Not all of the server say ok , send an ERROR to the client ");
                                    outToClient.println("ERROR");
                                }
                            }  else if (fileExist && LockState) {
                                if (FileLockHash.get(FileName).equals(ipofclient)) {
                                    SentenceServerMulti.logger.info("LOCK : OK ");
                                    outToClient.println("OK");
                                }
                                else {
                                    SentenceServerMulti.logger.info("LOCK :  ERROR to the client , the file already locked by : " + FileLockHash.get(FileName) );
                                    outToClient.println("ERROR");
                                }
                            }//end of client case
                        } else {//the file doest exist OR the fle locked alredy
                            SentenceServerMulti.logger.info("LOCK : ERROR - Not all of the server say ok , send an ERROR to the client ");
                            outToClient.println("ERROR");
                        }
                    }   catch (IOException e){
                        System.out.println("problem in Lock case");
                    }

                    System.out.println("LOCK :" + FileLockHash);
                    SentenceServerMulti.logger.info("LOCK hash map:" + FileLockHash);
                    break;
                }




//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//


                case "UNLOCK" : {

                    String FileName = AnswareFrom.nextLine();
                    String WhoCallMe = AnswareFrom.nextLine();////////// client or server call me ?
                    String ipofclient= AnswareFrom.nextLine();
                    System.out.println("ipofclient = " + ipofclient);
                    PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);
                  // String userIp = clientSock.getInetAddress().toString();
                    BufferedReader bufferedReader = null;
                    boolean LockState = FileLockHash.containsKey(FileName); //state of file - unlock or not
                    boolean fileExist = FileVersionHash.containsKey(FileName);

                   // System.out.println("LockState "+ LockState + "fileExist :" +fileExist  );

                    if(WhoCallMe.equals("client"))
                    {
                        SentenceServerMulti.logger.info("client call me !!");
                        int counterOfservers=0 ;
                        if (fileExist && LockState) { // if the file exist and the file is already  locked .
                            if (ipofclient.equals(FileLockHash.get(FileName))) { // check who locked that file- if the same user he can unlock it
                                //first unlock this file in this server
                                SentenceServerMulti.logger.info("Connect the other server that connect now and try unlock the file. ");
                                SentenceServerMulti.checkServerConnectedNow();//this function update the server connect now !

                                //the server send lock to all server he know .(listOfServersConnected list have all the ip that connect now)
                                for (String ipOfServer :SentenceServerMulti.listOfServersConnected)
                                {
                                    try {
                                        //connect to the server
                                        Socket socket1 = new Socket(ipOfServer, SentenceServerMulti.portNum);
                                        SentenceServerMulti.logger.info("connect to server " + ipOfServer +".");
                                        //send a msg to the server :
                                        DataOutputStream outToServer = new DataOutputStream(socket1.getOutputStream());
                                        outToServer.writeBytes("UNLOCK\n");
                                        PrintWriter pw1 = new PrintWriter(socket1.getOutputStream(), true);
                                        pw1.println(FileName); //THE NAME OF THE FILE TO THE OTHER SERVER
                                        pw1.println("server");
                                        pw1.println(ipofclient);

                                        SentenceServerMulti.logger.info("send UNLOCK " + FileName + " to the server " + ipOfServer);

                                        //Scanner to get information from the server
                                        Scanner scanner1 = new Scanner(socket1.getInputStream());
                                        //msg from the server!
                                        String msgFromServer = scanner1.nextLine();
                                        switch (msgFromServer) {
                                            case "OK":
                                                SentenceServerMulti.logger.info("UNLOCK :OK - the server " + ipOfServer + " send OK for UNLOCK");
                                                counterOfservers ++;
                                                break;
                                            case "ERROR":
                                                SentenceServerMulti.logger.info("UNLOCK : ERROR - the server " + ipOfServer + " send ERROR for UNLOCK");
                                                counterOfservers = 0 ;
                                                break;
                                            default:
                                                break;
                                        }
                                    }catch (SocketException e){

                                    }
                                }

                                SentenceServerMulti.logger.info("The first server check if all the other server send ok");

                                if(counterOfservers == SentenceServerMulti.listOfServersConnected.size() ) {
                                    SentenceServerMulti.logger.info("All servers say OK , lock the file " +FileName + " in this server");
                                    //lock the file in this server
                                    if(FileLockHash.containsKey(FileName)){
                                        FileLockHash.remove(FileName);
                                        System.out.println(FileLockHash);
                                    }
                                    SentenceServerMulti.logger.info("UNLOCK - OK - Return OK to the client");
                                    outToClient.println("OK");

                                }
                                else {
                                    SentenceServerMulti.logger.info("UNLOCK -ERROR - Not all of the server say ok , send an ERROR to the client ");
                                    outToClient.println("ERROR");
                                }
                            }
                            else {
                                SentenceServerMulti.logger.info("UNLOCK : ERROR - Not all of the server say ok , send an ERROR to the client ");
                                outToClient.println("ERROR");
                            }
                        }
                        else if(fileExist && !LockState){
                            SentenceServerMulti.logger.info("UNLOCK : ERROR - The file does not locked, you cant do unlock ! ");
                            outToClient.println("ERROR");
                        }
                    }



                    else if(WhoCallMe.equals("server")){
                        SentenceServerMulti.logger.info("server call me !!");

                        //if the file exist and locked yet , unlock it
                        if (fileExist && LockState ) {

                            if (ipofclient.equals(FileLockHash.get(FileName))){
                                FileLockHash.remove(FileName);
                                SentenceServerMulti.logger.info("UNLOCK : OK - success UNLOCK in the server who called !!");
                                outToClient.println("OK");

                            }
                            else {//the file not exist or the file locked already
                                SentenceServerMulti.logger.info("UNLOCK : ERROR - Failed UNLOCK in the server who called !!");
                                outToClient.println("ERROR");
                            }
                            System.out.println("unlock hash map  : " + FileLockHash);
                        }
                        else {//the file not exist or the file locked already
                            SentenceServerMulti.logger.info("UNLOCK : ERROR - Failed UNLOCK in the server who called !!");
                            outToClient.println("ERROR");
                        }
                    }
                    System.out.println("Unlock hash map : " + FileLockHash);
                   SentenceServerMulti.logger.info("Unlock hash map : " + FileLockHash);
                    break;
                }

//--------------------------------------------------------for the syncronize ---------------------------------------------------------------------------------------------------------------------------------
                case "GETVERSION1" :{
                    String Filename = AnswareFrom.nextLine();
                    System.out.println(Filename);
                    PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);

                    String data = FileVersionHash.get(Filename).toString();
                    outToClient.println(data); //return the version of this file to the client

                    if(FileLockHash.containsKey(Filename)){
                        String whoLockedTheFile = FileLockHash.get(Filename);
                        outToClient.println(whoLockedTheFile);
                    }
                    break;
                }



//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

                case "GETVERSION" : {

                    String Filename = AnswareFrom.nextLine();
                    String Version = "";
                    PrintWriter outToClient = new PrintWriter(clientSock.getOutputStream(), true);

                    //check if the file is saved in the path
                    String path = SentenceServerMulti.PathOfTheProject +"\\"+ SentenceServerMulti.pathUpload;
                    File folder = new File(path);
                    File[] listOfFile = folder.listFiles();

                    boolean bool = false;

                    for (int i = 0; i < listOfFile.length; i++) {
                        if (listOfFile[i].isFile()) {
                            if(listOfFile[i].getName().equals(Filename)){ // if the file exist
                                bool= true;
                                break;
                            }
                            else{
                                //THE FILE DOESNT EXIST
                            }
                        }
                    }

                    if(bool){
                        outToClient.println("OK");
                        SentenceServerMulti.logger.info("GETVERSION : OK");
                        String data = FileVersionHash.get(Filename).toString();
                        outToClient.println(data); //return the version of this file to the client
                        if(FileLockHash.containsKey(Filename)){
                            String whoLockedTheFile = FileLockHash.get(Filename);
                            outToClient.println(whoLockedTheFile);
                        }
                    }
                    else{
                        outToClient.println("ERROR"); // the file probebly dosnt exist
                        outToClient.println("File Not exist!"); //return the version of this file to the client
                        SentenceServerMulti.logger.info("GETVERSION : ERROR");
                    }

                    // VERSION digest datetime The line begins with VERSION (capitalization isn’t important) followed by one
                    // space. It’s followed by a version hash digest in hexadecimal format, a space, and a timestamp in ISO
                    // 8601 long date time format (e.g. 2021-10-29T08:27:22Z). The line ends with a new line character.

                    break;
                }

                default: {
                    break;
                }
            }
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

        } catch (IOException e) {
            System.out.println("Error in communication.  Closing.\n");
            SentenceServerMulti.logger.info("Error in communication.  Closing.\n");
            e.printStackTrace();
        }
        finally {
            //System.out.println("Finished and closed on " + clientSock.getRemoteSocketAddress().toString());
            try { clientSock.close(); } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return;
    }

}